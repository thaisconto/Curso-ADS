package com.example.ativ4.config.exceptions;
public class AgendaNaoDisponivelException extends RuntimeException {
    public AgendaNaoDisponivelException(String message) {
        super(message);
    }
}

package com.example.ativ4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ativ4Application {

	public static void main(String[] args) {
		SpringApplication.run(Ativ4Application.class, args);
	}

}

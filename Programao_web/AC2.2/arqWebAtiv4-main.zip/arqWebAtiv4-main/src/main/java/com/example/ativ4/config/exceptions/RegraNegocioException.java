package com.example.ativ4.config.exceptions;

public class RegraNegocioException extends RuntimeException {
    public RegraNegocioException(String message) {
        super(message);
    }

}

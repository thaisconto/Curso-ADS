package com.example.ativ4.config.exceptions;
public class EspecialidadeIncompativelException extends RuntimeException {
    public EspecialidadeIncompativelException(String message) {
        super(message);
    }
}
